using UnityEngine;

public class RVOController : Object {
	public float maxSpeed;
	
	public void Move(Vector3 go){}

}

