using UnityEngine;
using Pathfinding;

public static class FleePath {

	public static ABPath Construct (Vector3 v , Vector3 t , int l, OnPathDelegate o){return null;}
}

