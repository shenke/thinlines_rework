using UnityEngine;
using Pathfinding;

public static class RandomPath {
	public static ABPath Construct (Vector3 v , int l, OnPathDelegate o){return null;}

}

