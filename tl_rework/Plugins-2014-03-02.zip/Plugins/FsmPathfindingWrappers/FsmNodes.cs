using UnityEngine;
using Pathfinding;
using System.Collections.Generic;


namespace FsmPathfinding{
public class FsmNodes : FsmPathfindingBase {
	public new List<Node> Value;
}
}