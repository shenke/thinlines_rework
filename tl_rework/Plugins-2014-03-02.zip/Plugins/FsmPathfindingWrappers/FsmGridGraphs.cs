using UnityEngine;
using Pathfinding;

namespace FsmPathfinding{
	public class FsmGridGraphs : FsmPathfindingBase {
		public new GridGraph[] Value;
	}
}