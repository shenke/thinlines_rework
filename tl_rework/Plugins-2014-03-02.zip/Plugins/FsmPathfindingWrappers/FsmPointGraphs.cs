using UnityEngine;
using Pathfinding;

namespace FsmPathfinding{
	public class FsmPointGraphs : FsmPathfindingBase {
		public new PointGraph[] Value;
	}
}