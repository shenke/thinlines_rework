using UnityEngine;
using Pathfinding;

namespace FsmPathfinding{
	public class FsmAstarData : FsmPathfindingBase {
		public new AstarData Value;

	}
}