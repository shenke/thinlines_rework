using UnityEngine;
using Pathfinding;

public class FsmPathfindingBase : Object {
	public FsmPathfindingBase Value;

}
