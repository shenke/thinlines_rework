using UnityEngine;
using Pathfinding;

namespace FsmPathfinding{
	public class FsmNNConstraint : FsmPathfindingBase {
		public new NNConstraint Value;
	}
}