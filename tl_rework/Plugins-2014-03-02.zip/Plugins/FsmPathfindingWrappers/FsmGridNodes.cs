using UnityEngine;
using Pathfinding;


namespace FsmPathfinding{
public class FsmGridNodes : FsmPathfindingBase{
	public new Pathfinding.Nodes.GridNode[] Value;
}
}