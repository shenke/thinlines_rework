using UnityEngine;
using Pathfinding;

namespace FsmPathfinding{
	public class FsmGridNode : FsmPathfindingBase {
		public new Pathfinding.Nodes.GridNode Value;
	}
}