using UnityEngine;
using Pathfinding;

namespace FsmPathfinding{
public class FsmABPath : FsmPathfindingBase {
	public new ABPath Value;

	}

}