using UnityEngine;
using Pathfinding;

namespace FsmPathfinding{
	public class FsmGridGraph : FsmPathfindingBase {
		public new GridGraph Value;
	}
}