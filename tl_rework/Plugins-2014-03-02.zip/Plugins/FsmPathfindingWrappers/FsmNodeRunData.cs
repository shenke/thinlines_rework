using UnityEngine;
using Pathfinding;

namespace FsmPathfinding{
	public class FsmNodeRunData : FsmPathfindingBase {
		public new NodeRunData Value;
	}
}