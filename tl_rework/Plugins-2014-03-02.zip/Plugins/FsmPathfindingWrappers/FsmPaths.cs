using UnityEngine;
using Pathfinding;


namespace FsmPathfinding{
	public class FsmPaths : FsmPathfindingBase {
		public new Path[] Value;

	}

}