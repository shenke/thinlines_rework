using UnityEngine;
using Pathfinding;

namespace FsmPathfinding{
	public class FsmPath : FsmPathfindingBase {
		public new Path Value;

	}
}
