using UnityEngine;
using Pathfinding;

namespace FsmPathfinding{
	public class FsmAstarPath : FsmPathfindingBase {
		public new AstarPath Value;

	}

}